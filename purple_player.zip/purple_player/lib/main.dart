import 'dart:io';
import 'dart:math';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

// ---------- الألوان: بنفسجي فاتح + أسود ----------
const kBlack = Color(0xFF0B0812);
const kSurface = Color(0xFF17121F);
const kSurface2 = Color(0xFF221A2E);
const kPurple = Color(0xFFB794F6);
const kPurpleLight = Color(0xFFD9C6FF);
const kPurpleDeep = Color(0xFF7C4DDB);

const _videoExt = ['mp4', 'mkv', 'webm', '3gp', 'mov'];
const _allExt = [
  'mp3', 'm4a', 'wav', 'aac', 'ogg', 'flac', 'opus', //
  'mp4', 'mkv', 'webm', '3gp', 'mov',
];

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: kBlack,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const PurplePlayerApp());
}

class PurplePlayerApp extends StatelessWidget {
  const PurplePlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Purple Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kBlack,
        colorScheme: const ColorScheme.dark(
          primary: kPurple,
          secondary: kPurpleLight,
          surface: kSurface,
        ),
        sliderTheme: const SliderThemeData(
          activeTrackColor: kPurple,
          inactiveTrackColor: kSurface2,
          thumbColor: kPurpleLight,
          trackHeight: 4,
        ),
      ),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const PlayerPage(),
    );
  }
}

class Track {
  final String path;
  final String name;
  final bool isVideo;
  Track(this.path, this.name, this.isVideo);
}

class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key});

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  final List<Track> _tracks = [];
  int _index = -1;
  VideoPlayerController? _ctrl;
  bool _loading = false;
  bool _completing = false;
  bool _shuffle = false;
  int _repeat = 0; // 0 بدون، 1 الكل، 2 واحدة
  final _rand = Random();

  @override
  void dispose() {
    _ctrl?.removeListener(_onTick);
    _ctrl?.dispose();
    super.dispose();
  }

  // ---------- اختيار الملفات ----------
  Future<void> _pickFiles() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: _allExt,
    );
    if (result == null) return;
    final wasEmpty = _tracks.isEmpty;
    for (final f in result.files) {
      final p = f.path;
      if (p == null) continue;
      if (_tracks.any((t) => t.path == p)) continue;
      final ext = f.extension?.toLowerCase() ?? '';
      _tracks.add(Track(p, f.name, _videoExt.contains(ext)));
    }
    setState(() {});
    if (wasEmpty && _tracks.isNotEmpty) _play(0);
  }

  // ---------- التشغيل ----------
  Future<void> _play(int i) async {
    if (i < 0 || i >= _tracks.length) return;
    setState(() {
      _loading = true;
      _index = i;
    });
    final old = _ctrl;
    old?.removeListener(_onTick);
    final c = VideoPlayerController.file(File(_tracks[i].path));
    _ctrl = c;
    _completing = false;
    try {
      await c.initialize();
      c.addListener(_onTick);
      await c.play();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذّر تشغيل هذا الملف')),
        );
      }
    }
    await old?.dispose();
    if (mounted) setState(() => _loading = false);
  }

  void _onTick() {
    final c = _ctrl;
    if (c == null || !mounted) return;
    final v = c.value;
    if (v.isInitialized &&
        !_completing &&
        v.duration.inMilliseconds > 0 &&
        v.position >= v.duration &&
        !v.isPlaying) {
      _completing = true;
      _onComplete();
    }
    setState(() {});
  }

  void _onComplete() {
    if (_repeat == 2) {
      _ctrl?.seekTo(Duration.zero);
      _ctrl?.play();
      _completing = false;
      return;
    }
    final isLast = _index == _tracks.length - 1;
    if (!_shuffle && isLast && _repeat == 0) return;
    _next();
  }

  void _next() {
    if (_tracks.isEmpty) return;
    if (_shuffle && _tracks.length > 1) {
      int n;
      do {
        n = _rand.nextInt(_tracks.length);
      } while (n == _index);
      _play(n);
    } else {
      _play((_index + 1) % _tracks.length);
    }
  }

  void _prev() {
    if (_tracks.isEmpty) return;
    final c = _ctrl;
    if (c != null && c.value.position.inSeconds > 3) {
      c.seekTo(Duration.zero);
      return;
    }
    _play((_index - 1 + _tracks.length) % _tracks.length);
  }

  void _togglePlay() {
    final c = _ctrl;
    if (c == null || !c.value.isInitialized) return;
    if (c.value.position >= c.value.duration) {
      c.seekTo(Duration.zero);
      _completing = false;
    }
    c.value.isPlaying ? c.pause() : c.play();
  }

  Future<void> _remove(int i) async {
    final removingCurrent = i == _index;
    _tracks.removeAt(i);
    if (removingCurrent) {
      _ctrl?.removeListener(_onTick);
      await _ctrl?.dispose();
      _ctrl = null;
      _index = -1;
      setState(() {});
      if (_tracks.isNotEmpty) _play(min(i, _tracks.length - 1));
    } else {
      if (i < _index) _index--;
      setState(() {});
    }
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
  }

  // ---------- الواجهة ----------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _header(),
            if (_tracks.isEmpty)
              Expanded(child: _emptyState())
            else ...[
              _nowPlaying(),
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 4, 20, 8),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text('قائمة التشغيل',
                      style: TextStyle(
                          color: kPurpleLight,
                          fontSize: 16,
                          fontWeight: FontWeight.w600)),
                ),
              ),
              Expanded(child: _playlist()),
            ],
          ],
        ),
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 12, 8),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [kPurpleLight, kPurpleDeep],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.graphic_eq_rounded, color: kBlack),
          ),
          const SizedBox(width: 12),
          const Text('مشغل الأغاني',
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: kPurpleLight)),
          const Spacer(),
          IconButton.filled(
            onPressed: _pickFiles,
            style: IconButton.styleFrom(
                backgroundColor: kPurple, foregroundColor: kBlack),
            icon: const Icon(Icons.add_rounded),
            tooltip: 'إضافة ملفات',
          ),
        ],
      ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kSurface,
                border: Border.all(color: kPurple.withOpacity(0.4), width: 2),
              ),
              child: const Icon(Icons.library_music_rounded,
                  size: 56, color: kPurple),
            ),
            const SizedBox(height: 24),
            const Text('ما في أغاني لسه',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            const Text('أضف ملفات MP3 أو MP4 من جهازك وابدأ التشغيل',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _pickFiles,
              style: FilledButton.styleFrom(
                backgroundColor: kPurple,
                foregroundColor: kBlack,
                padding:
                    const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
              ),
              icon: const Icon(Icons.folder_open_rounded),
              label: const Text('اختيار ملفات'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _nowPlaying() {
    final c = _ctrl;
    final ready = c != null && c.value.isInitialized;
    final track = _index >= 0 ? _tracks[_index] : null;
    final pos = ready ? c.value.position : Duration.zero;
    final dur = ready ? c.value.duration : Duration.zero;
    final playing = ready && c.value.isPlaying;
    final maxMs = max(dur.inMilliseconds, 1).toDouble();

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF2A1B45), kSurface],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: kPurple.withOpacity(0.25)),
      ),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: SizedBox(
              height: 190,
              width: double.infinity,
              child: (track != null && track.isVideo && ready)
                  ? Container(
                      color: Colors.black,
                      child: Center(
                        child: AspectRatio(
                          aspectRatio: c.value.aspectRatio,
                          child: VideoPlayer(c),
                        ),
                      ),
                    )
                  : Container(
                      decoration: const BoxDecoration(
                        gradient: RadialGradient(
                          colors: [kPurpleDeep, kBlack],
                          radius: 0.9,
                        ),
                      ),
                      child: Center(
                        child: _loading
                            ? const CircularProgressIndicator(color: kPurpleLight)
                            : Icon(
                                playing
                                    ? Icons.graphic_eq_rounded
                                    : Icons.music_note_rounded,
                                size: 80,
                                color: kPurpleLight,
                              ),
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            track?.name ?? '',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
          ),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Column(
              children: [
                Slider(
                  value: pos.inMilliseconds.toDouble().clamp(0, maxMs),
                  max: maxMs,
                  onChanged: ready
                      ? (v) => c.seekTo(Duration(milliseconds: v.toInt()))
                      : null,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_fmt(pos),
                          style: const TextStyle(
                              color: Colors.white60, fontSize: 12)),
                      Text(_fmt(dur),
                          style: const TextStyle(
                              color: Colors.white60, fontSize: 12)),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      onPressed: () => setState(() => _shuffle = !_shuffle),
                      icon: Icon(Icons.shuffle_rounded,
                          color: _shuffle ? kPurple : Colors.white38),
                    ),
                    IconButton(
                      iconSize: 36,
                      onPressed: _prev,
                      icon: const Icon(Icons.skip_previous_rounded,
                          color: kPurpleLight),
                    ),
                    Container(
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle, color: kPurple),
                      child: IconButton(
                        iconSize: 40,
                        padding: const EdgeInsets.all(12),
                        onPressed: _togglePlay,
                        icon: Icon(
                            playing
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                            color: kBlack),
                      ),
                    ),
                    IconButton(
                      iconSize: 36,
                      onPressed: _next,
                      icon: const Icon(Icons.skip_next_rounded,
                          color: kPurpleLight),
                    ),
                    IconButton(
                      onPressed: () =>
                          setState(() => _repeat = (_repeat + 1) % 3),
                      icon: Icon(
                        _repeat == 2
                            ? Icons.repeat_one_rounded
                            : Icons.repeat_rounded,
                        color: _repeat == 0 ? Colors.white38 : kPurple,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _playlist() {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      itemCount: _tracks.length,
      itemBuilder: (context, i) {
        final t = _tracks[i];
        final current = i == _index;
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(
            color: current ? kSurface2 : kSurface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: current ? kPurple : Colors.transparent, width: 1.2),
          ),
          child: ListTile(
            onTap: () => _play(i),
            leading: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: current ? kPurple : kSurface2,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                t.isVideo ? Icons.movie_rounded : Icons.music_note_rounded,
                color: current ? kBlack : kPurpleLight,
              ),
            ),
            title: Text(t.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: current ? kPurpleLight : Colors.white,
                    fontWeight: current ? FontWeight.w600 : FontWeight.normal)),
            subtitle: Text(t.isVideo ? 'فيديو' : 'صوت',
                style: const TextStyle(color: Colors.white38, fontSize: 12)),
            trailing: IconButton(
              icon: const Icon(Icons.close_rounded, color: Colors.white38),
              onPressed: () => _remove(i),
            ),
          ),
        );
      },
    );
  }
}
