import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:audio_service/audio_service.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:video_player/video_player.dart';

import 'audio_handler.dart';

// ---------- الألوان: بنفسجي فاتح + أسود ----------
const kBlack = Color(0xFF0B0812);
const kSurface = Color(0xFF17121F);
const kSurface2 = Color(0xFF221A2E);
const kPurple = Color(0xFFB794F6);
const kPurpleLight = Color(0xFFD9C6FF);
const kPurpleDeep = Color(0xFF7C4DDB);

const _videoExt = ['mp4', 'mkv', 'webm', '3gp', 'mov'];
const _allExt = [
  'mp3', 'm4a', 'wav', 'aac', 'ogg', 'flac', 'opus', //
  'mp4', 'mkv', 'webm', '3gp', 'mov',
];

final messengerKey = GlobalKey<ScaffoldMessengerState>();
late PlayerController controller;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final handler = await AudioService.init<PurpleAudioHandler>(
    builder: () => PurpleAudioHandler(),
    config: AudioServiceConfig(
      androidNotificationChannelId: 'com.university.purple_player.audio',
      androidNotificationChannelName: 'تشغيل الأغاني',
      androidNotificationOngoing: true,
    ),
  );
  controller = PlayerController(handler);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: kBlack,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const PurplePlayerApp());
}

class PurplePlayerApp extends StatelessWidget {
  const PurplePlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Purple Player',
      debugShowCheckedModeBanner: false,
      scaffoldMessengerKey: messengerKey,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kBlack,
        colorScheme: const ColorScheme.dark(
          primary: kPurple,
          secondary: kPurpleLight,
          surface: kSurface,
        ),
        sliderTheme: const SliderThemeData(
          activeTrackColor: kPurple,
          inactiveTrackColor: kSurface2,
          thumbColor: kPurpleLight,
          trackHeight: 4,
        ),
      ),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const LibraryPage(),
    );
  }
}

// =====================================================================
// النماذج
// =====================================================================
class Track {
  final String uri; // content:// أو مسار ملف
  final String title;
  final String artist;
  final bool isVideo;
  final Duration? duration;

  Track({
    required this.uri,
    required this.title,
    this.artist = '',
    this.isVideo = false,
    this.duration,
  });

  Uri get asUri => uri.startsWith('/') ? Uri.file(uri) : Uri.parse(uri);

  MediaItem toMediaItem() => MediaItem(
        id: asUri.toString(),
        title: title,
        artist: artist.isEmpty ? null : artist,
        duration: duration,
      );
}

enum PlayMode { none, audio, video }

String fmt(Duration d) {
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
}

// أنماط المعادل: منحنى من 5 نقاط (من الباس للتريبل) كنسبة من أقصى ديسيبل
const Map<String, List<double>> kPresets = {
  'Flat': [0, 0, 0, 0, 0],
  'Rock': [0.5, 0.3, -0.25, 0.35, 0.55],
  'Jazz': [0.35, 0.15, -0.2, 0.2, 0.45],
  'Dance': [0.7, 0.45, 0.0, 0.25, 0.4],
  'Pop': [-0.1, 0.25, 0.4, 0.2, -0.1],
  'Bass': [0.8, 0.5, 0.1, 0.0, 0.0],
};
const Map<String, String> kPresetNames = {
  'Flat': 'عادي (Flat)',
  'Rock': 'روك (Rock)',
  'Jazz': 'جاز (Jazz)',
  'Dance': 'دانس (Dance)',
  'Pop': 'بوب (Pop)',
  'Bass': 'باس عالي (Bass)',
  'custom': 'مخصص',
};

// =====================================================================
// المتحكم: كل منطق التشغيل هنا وتستخدمه كل الشاشات
// =====================================================================
class PlayerController extends ChangeNotifier {
  PlayerController(this.handler) {
    _init();
  }

  static const _media = MethodChannel('purple/media');

  final PurpleAudioHandler handler;
  AudioPlayer get _audio => handler.player;
  VideoPlayerController? video;
  final List<StreamSubscription> _subs = [];

  final List<Track> library = [];
  final List<Track> manual = [];
  List<String> _queueUris = [];

  PlayMode mode = PlayMode.none;
  Track? current;
  final ValueNotifier<Duration> position = ValueNotifier(Duration.zero);
  Duration dur = Duration.zero;
  bool playing = false;
  bool loading = false;
  bool scanning = true;
  bool denied = false;
  bool notificationsOff = false;
  bool shuffle = false;
  int repeat = 0; // 0 بدون، 1 الكل، 2 واحدة
  String preset = 'Flat';
  bool _videoDone = false;

  List<Track> get all => [...library, ...manual];

  void toast(String msg) {
    messengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  void _init() {
    _subs.add(_audio.positionStream.listen((p) {
      if (mode == PlayMode.audio) position.value = p;
    }));
    _subs.add(_audio.durationStream.listen((d) {
      if (mode == PlayMode.audio && d != null && d != dur) {
        dur = d;
        notifyListeners();
      }
    }));
    _subs.add(_audio.playerStateStream.listen((s) {
      if (mode != PlayMode.audio) return;
      final p = s.playing && s.processingState != ProcessingState.completed;
      final l = s.processingState == ProcessingState.loading;
      if (p != playing || l != loading) {
        playing = p;
        loading = l;
        notifyListeners();
      }
    }));
    _subs.add(_audio.currentIndexStream.listen((i) {
      if (mode != PlayMode.audio || i == null) return;
      if (i < 0 || i >= _queueUris.length) return;
      final uri = _queueUris[i];
      final match = all.where((t) => t.uri == uri);
      if (match.isNotEmpty) {
        current = match.first;
        position.value = Duration.zero;
        dur = match.first.duration ?? dur;
        notifyListeners();
      }
    }));
    _subs.add(_audio.playbackEventStream.listen((_) {}, onError: (Object e) {
      toast('تعذّر تشغيل هذا الملف');
    }));
    scan();
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    video?.removeListener(_onVideoTick);
    video?.dispose();
    super.dispose();
  }

  // ---------- الصلاحيات والإشعارات ----------
  Future<void> checkNotifications() async {
    try {
      final ok = await _media.invokeMethod<bool>('notificationsEnabled') ?? true;
      if (notificationsOff == ok) {
        notificationsOff = !ok;
        notifyListeners();
      }
    } catch (_) {}
  }

  Future<void> openNotificationSettings() async {
    try {
      await _media.invokeMethod('openNotificationSettings');
    } catch (_) {}
  }

  Future<void> openAppSettings() async {
    try {
      await _media.invokeMethod('openSettings');
    } catch (_) {}
  }

  // ---------- مسح أغاني التليفون ----------
  Future<void> scan() async {
    scanning = true;
    denied = false;
    notifyListeners();
    bool ok = false;
    try {
      ok = await _media
              .invokeMethod<bool>('requestPermission', {'kind': 'audio'}) ??
          false;
    } catch (_) {}
    if (!ok) {
      scanning = false;
      denied = true;
      notifyListeners();
      return;
    }
    // صلاحية الإشعارات (أندرويد 13+) بدون تعطيل المسح
    _media
        .invokeMethod('requestPermission', {'kind': 'notification'})
        .then((_) => checkNotifications())
        .catchError((_) {});
    try {
      final res = await _media.invokeMethod<List<dynamic>>('queryAudio') ?? [];
      final list = <Track>[];
      for (final e in res) {
        final m = Map<String, dynamic>.from(e as Map);
        final artist = (m['artist'] as String?) ?? '';
        final ms = (m['duration'] as num?)?.toInt() ?? 0;
        list.add(Track(
          uri: m['uri'] as String,
          title: (m['title'] as String?) ?? 'بدون عنوان',
          artist: artist == '<unknown>' ? '' : artist,
          duration: ms > 0 ? Duration(milliseconds: ms) : null,
        ));
      }
      list.sort(
          (a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
      library
        ..clear()
        ..addAll(list);
    } catch (_) {}
    scanning = false;
    notifyListeners();
    checkNotifications();
  }

  // ---------- إضافة ملفات يدويًا (فيديو أو غيره) ----------
  Future<void> pickFiles() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: _allExt,
    );
    if (result == null) return;
    Track? first;
    for (final f in result.files) {
      final p = f.path;
      if (p == null) continue;
      if (all.any((t) => t.uri == p)) continue;
      final ext = (f.extension ?? '').toLowerCase();
      final t = Track(
        uri: p,
        title: f.name.replaceFirst(RegExp(r'\.[^.]+$'), ''),
        isVideo: _videoExt.contains(ext),
      );
      manual.add(t);
      first ??= t;
    }
    notifyListeners();
    if (first != null && current == null) playTrack(first);
  }

  // ---------- التشغيل ----------
  Future<void> playTrack(Track t) async {
    if (t.isVideo) {
      await _playVideo(t);
    } else {
      await _playAudio(t);
    }
  }

  bool _same(List<String> a, List<String> b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  Future<void> _playAudio(Track t) async {
    await _disposeVideo();
    final tracks = all.where((x) => !x.isVideo).toList();
    final uris = tracks.map((x) => x.uri).toList();
    final idx = uris.indexOf(t.uri);
    if (idx < 0) return;
    mode = PlayMode.audio;
    current = t;
    position.value = Duration.zero;
    dur = t.duration ?? Duration.zero;
    loading = true;
    notifyListeners();
    try {
      if (!_same(uris, _queueUris)) {
        _queueUris = uris;
        await handler.loadQueue([for (final x in tracks) x.toMediaItem()], idx);
      } else {
        await _audio.seek(Duration.zero, index: idx);
      }
      handler.play();
    } catch (_) {
      toast('تعذّر تشغيل هذا الملف');
    }
    loading = false;
    notifyListeners();
  }

  Future<void> _playVideo(Track t) async {
    _queueUris = [];
    try {
      await handler.stop();
    } catch (_) {}
    await _disposeVideo();
    mode = PlayMode.video;
    current = t;
    position.value = Duration.zero;
    dur = t.duration ?? Duration.zero;
    loading = true;
    playing = false;
    _videoDone = false;
    notifyListeners();
    final c = VideoPlayerController.file(File(t.uri));
    video = c;
    try {
      await c.initialize();
      c.addListener(_onVideoTick);
      await c.play();
    } catch (_) {
      toast('تعذّر تشغيل هذا الملف');
    }
    loading = false;
    notifyListeners();
  }

  Future<void> _disposeVideo() async {
    final c = video;
    video = null;
    c?.removeListener(_onVideoTick);
    await c?.dispose();
  }

  void _onVideoTick() {
    final c = video;
    if (c == null || mode != PlayMode.video) return;
    final v = c.value;
    position.value = v.position;
    var changed = false;
    if (v.isInitialized && v.duration != dur) {
      dur = v.duration;
      changed = true;
    }
    if (v.isPlaying != playing) {
      playing = v.isPlaying;
      changed = true;
    }
    if (v.isInitialized &&
        !_videoDone &&
        v.duration.inMilliseconds > 0 &&
        v.position >= v.duration &&
        !v.isPlaying) {
      _videoDone = true;
      _onVideoComplete();
    }
    if (changed) notifyListeners();
  }

  void _onVideoComplete() {
    if (repeat == 2) {
      video?.seekTo(Duration.zero);
      video?.play();
      _videoDone = false;
      return;
    }
    _skip(1, auto: true);
  }

  void _skip(int delta, {bool auto = false}) {
    final list = all;
    final cur = current;
    if (list.isEmpty || cur == null) return;
    var i = list.indexWhere((t) => t.uri == cur.uri) + delta;
    if (auto && i >= list.length && repeat == 0) return;
    i = (i + list.length) % list.length;
    playTrack(list[i]);
  }

  void togglePlay() {
    if (mode == PlayMode.audio) {
      final a = _audio;
      if (a.processingState == ProcessingState.completed) {
        a.seek(Duration.zero, index: 0);
        handler.play();
      } else if (a.playing) {
        handler.pause();
      } else {
        handler.play();
      }
    } else if (mode == PlayMode.video) {
      final c = video;
      if (c == null || !c.value.isInitialized) return;
      if (c.value.position >= c.value.duration) {
        c.seekTo(Duration.zero);
        _videoDone = false;
      }
      c.value.isPlaying ? c.pause() : c.play();
    }
  }

  void next() {
    if (mode == PlayMode.audio) {
      handler.skipToNext();
    } else if (mode == PlayMode.video) {
      _skip(1);
    }
  }

  void prev() {
    if (mode == PlayMode.audio) {
      handler.skipToPrevious();
    } else if (mode == PlayMode.video) {
      if (position.value.inSeconds > 3) {
        video?.seekTo(Duration.zero);
      } else {
        _skip(-1);
      }
    }
  }

  void seek(Duration d) {
    if (mode == PlayMode.audio) {
      _audio.seek(d);
    } else if (mode == PlayMode.video) {
      video?.seekTo(d);
    }
  }

  void toggleShuffle() {
    shuffle = !shuffle;
    handler.setShuffle(shuffle);
    notifyListeners();
  }

  void cycleRepeat() {
    repeat = (repeat + 1) % 3;
    handler.setLoop(repeat);
    notifyListeners();
  }

  // ---------- المعادل ----------
  Future<AndroidEqualizerParameters?> eqParams() async {
    try {
      return await handler.equalizer.parameters;
    } catch (_) {
      return null;
    }
  }

  double _interp(List<double> c, double t) {
    final x = t * (c.length - 1);
    final lo = x.floor();
    final hi = min(lo + 1, c.length - 1);
    return c[lo] + (c[hi] - c[lo]) * (x - lo);
  }

  /// يطبّق نمطًا جاهزًا ويرجع قيم الـ dB لكل نطاق.
  Future<List<double>> applyPreset(
      String name, AndroidEqualizerParameters p) async {
    final curve = kPresets[name] ?? kPresets['Flat']!;
    final n = p.bands.length;
    final gains = <double>[];
    for (var i = 0; i < n; i++) {
      final t = n == 1 ? 0.0 : i / (n - 1);
      final f = _interp(curve, t);
      var g = f >= 0 ? f * p.maxDecibels : f * -p.minDecibels;
      g = g.clamp(p.minDecibels, p.maxDecibels).toDouble();
      gains.add(g);
      await p.bands[i].setGain(g);
    }
    try {
      await handler.equalizer.setEnabled(name != 'Flat');
    } catch (_) {}
    preset = name;
    notifyListeners();
    return gains;
  }

  Future<void> setBand(AndroidEqualizerBand band, double gain) async {
    await band.setGain(gain);
    try {
      await handler.equalizer.setEnabled(true);
    } catch (_) {}
    if (preset != 'custom') {
      preset = 'custom';
      notifyListeners();
    }
  }
}

// =====================================================================
// شاشة قائمة الأغاني
// =====================================================================
class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});

  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> with WidgetsBindingObserver {
  final ctrl = controller;
  bool _searching = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      ctrl.checkNotifications();
      if (ctrl.denied && !ctrl.scanning) ctrl.scan();
    }
  }

  void _openPlayer() {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => NowPlayingPage(ctrl: ctrl)));
  }

  void _onTap(Track t) {
    if (ctrl.current?.uri != t.uri) ctrl.playTrack(t);
    _openPlayer();
  }

  List<Track> _filtered() {
    final q = _query.trim().toLowerCase();
    final list = ctrl.all;
    if (q.isEmpty) return list;
    return list
        .where((t) =>
            t.title.toLowerCase().contains(q) ||
            t.artist.toLowerCase().contains(q))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ctrl,
      builder: (context, _) {
        final list = _filtered();
        return Scaffold(
          body: SafeArea(
            child: Column(
              children: [
                _header(),
                if (ctrl.notificationsOff) _notifBanner(),
                if (_searching) _searchBar(),
                Expanded(child: _body(list)),
                if (ctrl.current != null) _miniPlayer(),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 8, 8),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [kPurpleLight, kPurpleDeep],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.graphic_eq_rounded, color: kBlack),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text('مشغل الأغاني',
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: kPurpleLight)),
          ),
          IconButton(
            tooltip: 'بحث',
            onPressed: () => setState(() {
              _searching = !_searching;
              if (!_searching) _query = '';
            }),
            icon: Icon(
                _searching ? Icons.search_off_rounded : Icons.search_rounded,
                color: kPurpleLight),
          ),
          IconButton(
            tooltip: 'تحديث القائمة',
            onPressed: ctrl.scanning ? null : ctrl.scan,
            icon: const Icon(Icons.refresh_rounded, color: kPurpleLight),
          ),
          IconButton(
            tooltip: 'إضافة ملفات',
            onPressed: ctrl.pickFiles,
            icon:
                const Icon(Icons.add_circle_rounded, color: kPurple, size: 30),
          ),
        ],
      ),
    );
  }

  Widget _notifBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
      decoration: BoxDecoration(
        color: const Color(0xFF3A2A12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFFC857).withOpacity(0.6)),
      ),
      child: Row(
        children: [
          const Icon(Icons.notifications_off_rounded, color: Color(0xFFFFC857)),
          const SizedBox(width: 10),
          const Expanded(
            child: Text(
              'الإشعارات متوقفة، فعّلها عشان يظهر شريط التحكم في قائمة الإشعارات',
              style: TextStyle(fontSize: 13),
            ),
          ),
          TextButton(
            onPressed: ctrl.openNotificationSettings,
            child: const Text('تفعيل'),
          ),
        ],
      ),
    );
  }

  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: TextField(
        autofocus: true,
        onChanged: (v) => setState(() => _query = v),
        decoration: InputDecoration(
          hintText: 'ابحث عن أغنية...',
          prefixIcon: const Icon(Icons.search_rounded, color: kPurple),
          filled: true,
          fillColor: kSurface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _body(List<Track> list) {
    if (list.isEmpty) {
      if (ctrl.scanning) {
        return const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: kPurple),
              SizedBox(height: 16),
              Text('جاري البحث عن الأغاني...',
                  style: TextStyle(color: Colors.white60)),
            ],
          ),
        );
      }
      if (ctrl.denied) {
        return _message(
          icon: Icons.lock_outline_rounded,
          title: 'نحتاج صلاحية الوصول للأغاني',
          text:
              'اسمح للتطبيق بقراءة ملفات الصوت عشان يعرض لك الأغاني اللي في التليفون',
          buttons: [
            FilledButton.icon(
              onPressed: ctrl.scan,
              style: FilledButton.styleFrom(
                  backgroundColor: kPurple, foregroundColor: kBlack),
              icon: const Icon(Icons.check_rounded),
              label: const Text('السماح'),
            ),
            OutlinedButton.icon(
              onPressed: ctrl.openAppSettings,
              icon: const Icon(Icons.settings_rounded),
              label: const Text('فتح الإعدادات'),
            ),
          ],
        );
      }
      if (_query.isNotEmpty) {
        return _message(
          icon: Icons.search_off_rounded,
          title: 'ما في نتائج',
          text: 'جرّب كلمة تانية',
        );
      }
      return _message(
        icon: Icons.library_music_rounded,
        title: 'ما لقينا أغاني في التليفون',
        text: 'تقدر تضيف ملفات MP3 أو MP4 يدويًا',
        buttons: [
          FilledButton.icon(
            onPressed: ctrl.pickFiles,
            style: FilledButton.styleFrom(
                backgroundColor: kPurple, foregroundColor: kBlack),
            icon: const Icon(Icons.folder_open_rounded),
            label: const Text('اختيار ملفات'),
          ),
        ],
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      itemCount: list.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(4, 4, 4, 10),
            child: Text(
              ctrl.scanning
                  ? 'قائمة الأغاني (جاري التحديث...)'
                  : 'قائمة الأغاني (${list.length})',
              style: const TextStyle(
                  color: kPurpleLight,
                  fontSize: 16,
                  fontWeight: FontWeight.w600),
            ),
          );
        }
        return _tile(list[i - 1]);
      },
    );
  }

  Widget _message({
    required IconData icon,
    required String title,
    required String text,
    List<Widget> buttons = const [],
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kSurface,
                border: Border.all(color: kPurple.withOpacity(0.4), width: 2),
              ),
              child: Icon(icon, size: 52, color: kPurple),
            ),
            const SizedBox(height: 20),
            Text(title,
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text(text,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white60)),
            const SizedBox(height: 20),
            Wrap(spacing: 12, runSpacing: 8, children: buttons),
          ],
        ),
      ),
    );
  }

  Widget _tile(Track t) {
    final isCurrent = ctrl.current?.uri == t.uri;
    final sub = t.isVideo
        ? 'فيديو'
        : [
            if (t.artist.isNotEmpty) t.artist,
            if (t.duration != null) fmt(t.duration!),
          ].join(' • ');
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: isCurrent ? kSurface2 : kSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: isCurrent ? kPurple : Colors.transparent, width: 1.2),
      ),
      child: ListTile(
        onTap: () => _onTap(t),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: isCurrent ? kPurple : kSurface2,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            isCurrent && ctrl.playing
                ? Icons.graphic_eq_rounded
                : (t.isVideo ? Icons.movie_rounded : Icons.music_note_rounded),
            color: isCurrent ? kBlack : kPurpleLight,
          ),
        ),
        title: Text(t.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
                color: isCurrent ? kPurpleLight : Colors.white,
                fontWeight: isCurrent ? FontWeight.w600 : FontWeight.normal)),
        subtitle: sub.isEmpty
            ? null
            : Text(sub,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white38, fontSize: 12)),
      ),
    );
  }

  // الشريط الصغير تحت القائمة: يرجّعك لشاشة التشغيل الكاملة
  Widget _miniPlayer() {
    final t = ctrl.current!;
    return GestureDetector(
      onTap: _openPlayer,
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        padding: const EdgeInsets.fromLTRB(12, 10, 8, 8),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [Color(0xFF2A1B45), kSurface2],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: kPurple.withOpacity(0.35)),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: kPurple,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                      t.isVideo
                          ? Icons.movie_rounded
                          : (ctrl.playing
                              ? Icons.graphic_eq_rounded
                              : Icons.music_note_rounded),
                      color: kBlack),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(t.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 15)),
                      Text(
                          t.artist.isNotEmpty
                              ? t.artist
                              : (ctrl.loading ? 'جاري التحميل...' : 'اضغط لفتح المشغل'),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white54, fontSize: 12)),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: ctrl.togglePlay,
                  icon: Icon(
                      ctrl.playing
                          ? Icons.pause_circle_filled_rounded
                          : Icons.play_circle_fill_rounded,
                      size: 38,
                      color: kPurple),
                ),
                IconButton(
                  onPressed: ctrl.next,
                  icon: const Icon(Icons.skip_next_rounded,
                      color: kPurpleLight, size: 30),
                ),
              ],
            ),
            const SizedBox(height: 6),
            ValueListenableBuilder<Duration>(
              valueListenable: ctrl.position,
              builder: (context, p, _) {
                final total = max(ctrl.dur.inMilliseconds, 1);
                return ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: (p.inMilliseconds / total).clamp(0.0, 1.0).toDouble(),
                    minHeight: 3,
                    backgroundColor: kBlack,
                    color: kPurple,
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

// =====================================================================
// شاشة التشغيل الكاملة
// =====================================================================
class NowPlayingPage extends StatelessWidget {
  final PlayerController ctrl;
  const NowPlayingPage({super.key, required this.ctrl});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF2A1B45), kBlack],
            begin: Alignment.topCenter,
            end: Alignment.center,
          ),
        ),
        child: SafeArea(
          child: ListenableBuilder(
            listenable: ctrl,
            builder: (context, _) {
              final t = ctrl.current;
              if (t == null) {
                return const Center(child: Text('ما في شيء قيد التشغيل'));
              }
              return Column(
                children: [
                  _topBar(context),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 28),
                      child: Center(child: _art()),
                    ),
                  ),
                  _titleBlock(t),
                  _seekBar(),
                  _controls(),
                  _eqButton(context),
                  const SizedBox(height: 16),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _topBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
      child: Row(
        children: [
          IconButton(
            tooltip: 'رجوع للقائمة',
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.keyboard_arrow_down_rounded,
                size: 36, color: kPurpleLight),
          ),
          const Expanded(
            child: Text('قيد التشغيل',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: kPurpleLight)),
          ),
          IconButton(
            tooltip: 'المعادل',
            onPressed: () => showEqualizerSheet(context, ctrl),
            icon: const Icon(Icons.equalizer_rounded, color: kPurple),
          ),
        ],
      ),
    );
  }

  Widget _art() {
    final c = ctrl.video;
    if (ctrl.mode == PlayMode.video && c != null && c.value.isInitialized) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Container(
          color: Colors.black,
          child: AspectRatio(
            aspectRatio: c.value.aspectRatio,
            child: VideoPlayer(c),
          ),
        ),
      );
    }
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(32),
          gradient: const RadialGradient(
              colors: [kPurpleDeep, Color(0xFF1B1030)], radius: 0.95),
          border: Border.all(color: kPurple.withOpacity(0.35)),
          boxShadow: [
            BoxShadow(
                color: kPurpleDeep.withOpacity(0.35),
                blurRadius: 40,
                spreadRadius: 2),
          ],
        ),
        child: Center(
          child: ctrl.loading
              ? const CircularProgressIndicator(color: kPurpleLight)
              : Icon(
                  ctrl.playing
                      ? Icons.graphic_eq_rounded
                      : Icons.music_note_rounded,
                  size: 110,
                  color: kPurpleLight),
        ),
      ),
    );
  }

  Widget _titleBlock(Track t) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 16, 28, 4),
      child: Column(
        children: [
          Text(t.title,
              maxLines: 2,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              style:
                  const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          if (t.artist.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(t.artist,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white60, fontSize: 15)),
          ],
        ],
      ),
    );
  }

  Widget _seekBar() {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: ValueListenableBuilder<Duration>(
        valueListenable: ctrl.position,
        builder: (context, pos, _) {
          final maxMs = max(ctrl.dur.inMilliseconds, 1).toDouble();
          final v = pos.inMilliseconds.toDouble().clamp(0.0, maxMs).toDouble();
          return Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Column(
              children: [
                Slider(
                  value: v,
                  max: maxMs,
                  onChanged: (x) => ctrl.seek(Duration(milliseconds: x.toInt())),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(fmt(pos),
                          style: const TextStyle(
                              color: Colors.white60, fontSize: 12)),
                      Text(fmt(ctrl.dur),
                          style: const TextStyle(
                              color: Colors.white60, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _controls() {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            IconButton(
              onPressed: ctrl.toggleShuffle,
              icon: Icon(Icons.shuffle_rounded,
                  color: ctrl.shuffle ? kPurple : Colors.white38),
            ),
            IconButton(
              iconSize: 42,
              onPressed: ctrl.prev,
              icon: const Icon(Icons.skip_previous_rounded,
                  color: kPurpleLight),
            ),
            Container(
              decoration:
                  const BoxDecoration(shape: BoxShape.circle, color: kPurple),
              child: IconButton(
                iconSize: 46,
                padding: const EdgeInsets.all(14),
                onPressed: ctrl.togglePlay,
                icon: Icon(
                    ctrl.playing
                        ? Icons.pause_rounded
                        : Icons.play_arrow_rounded,
                    color: kBlack),
              ),
            ),
            IconButton(
              iconSize: 42,
              onPressed: ctrl.next,
              icon: const Icon(Icons.skip_next_rounded, color: kPurpleLight),
            ),
            IconButton(
              onPressed: ctrl.cycleRepeat,
              icon: Icon(
                ctrl.repeat == 2
                    ? Icons.repeat_one_rounded
                    : Icons.repeat_rounded,
                color: ctrl.repeat == 0 ? Colors.white38 : kPurple,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _eqButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: OutlinedButton.icon(
        onPressed: () => showEqualizerSheet(context, ctrl),
        style: OutlinedButton.styleFrom(
          foregroundColor: kPurpleLight,
          side: BorderSide(color: kPurple.withOpacity(0.5)),
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
        ),
        icon: const Icon(Icons.equalizer_rounded),
        label: Text('المعادل: ${kPresetNames[ctrl.preset] ?? ctrl.preset}'),
      ),
    );
  }
}

// =====================================================================
// المعادل (ضبط الهيرتز)
// =====================================================================
Future<void> showEqualizerSheet(
    BuildContext context, PlayerController ctrl) async {
  if (ctrl.mode != PlayMode.audio) {
    ctrl.toast('المعادل يعمل مع الأغاني الصوتية فقط');
    return;
  }
  final params = await ctrl.eqParams();
  if (params == null) {
    ctrl.toast('المعادل غير متاح على هذا الجهاز');
    return;
  }
  if (!context.mounted) return;
  await showModalBottomSheet(
    context: context,
    backgroundColor: kSurface,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    builder: (_) => EqualizerSheet(ctrl: ctrl, params: params),
  );
}

class EqualizerSheet extends StatefulWidget {
  final PlayerController ctrl;
  final AndroidEqualizerParameters params;
  const EqualizerSheet({super.key, required this.ctrl, required this.params});

  @override
  State<EqualizerSheet> createState() => _EqualizerSheetState();
}

class _EqualizerSheetState extends State<EqualizerSheet> {
  late List<double> gains;
  late String preset;

  @override
  void initState() {
    super.initState();
    gains = [for (final b in widget.params.bands) b.gain];
    preset = widget.ctrl.preset;
  }

  Future<void> _apply(String name) async {
    final g = await widget.ctrl.applyPreset(name, widget.params);
    if (!mounted) return;
    setState(() {
      gains = g;
      preset = name;
    });
  }

  String _hz(double f) => f >= 1000
      ? '${(f / 1000).toStringAsFixed(f >= 10000 ? 0 : 1)} kHz'
      : '${f.round()} Hz';

  @override
  Widget build(BuildContext context) {
    final p = widget.params;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 44,
              height: 4,
              decoration: BoxDecoration(
                  color: Colors.white24, borderRadius: BorderRadius.circular(4)),
            ),
            const SizedBox(height: 14),
            const Text('المعادل (ضبط الهيرتز)',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: kPurpleLight)),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                for (final k in kPresets.keys)
                  ChoiceChip(
                    label: Text(kPresetNames[k]!),
                    selected: preset == k,
                    selectedColor: kPurple,
                    labelStyle: TextStyle(
                        color: preset == k ? kBlack : Colors.white,
                        fontWeight: FontWeight.w600),
                    backgroundColor: kSurface2,
                    onSelected: (_) => _apply(k),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  for (var i = 0; i < p.bands.length; i++)
                    Column(
                      children: [
                        Text('${gains[i].toStringAsFixed(0)} dB',
                            style: const TextStyle(
                                fontSize: 11, color: Colors.white60)),
                        SizedBox(
                          height: 170,
                          child: RotatedBox(
                            quarterTurns: 3,
                            child: Slider(
                              min: p.minDecibels,
                              max: p.maxDecibels,
                              value: gains[i]
                                  .clamp(p.minDecibels, p.maxDecibels)
                                  .toDouble(),
                              onChanged: (v) {
                                setState(() {
                                  gains[i] = v;
                                  preset = 'custom';
                                });
                                widget.ctrl.setBand(p.bands[i], v);
                              },
                            ),
                          ),
                        ),
                        Text(_hz(p.bands[i].centerFrequency),
                            style: const TextStyle(
                                fontSize: 11, color: kPurpleLight)),
                      ],
                    ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            const Text('المعادل يعمل على الأغاني الصوتية',
                style: TextStyle(color: Colors.white38, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
