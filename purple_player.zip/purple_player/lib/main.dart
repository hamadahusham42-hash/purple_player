import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:video_player/video_player.dart';

// ---------- الألوان: بنفسجي فاتح + أسود ----------
const kBlack = Color(0xFF0B0812);
const kSurface = Color(0xFF17121F);
const kSurface2 = Color(0xFF221A2E);
const kPurple = Color(0xFFB794F6);
const kPurpleLight = Color(0xFFD9C6FF);
const kPurpleDeep = Color(0xFF7C4DDB);

const _videoExt = ['mp4', 'mkv', 'webm', '3gp', 'mov'];
const _allExt = [
  'mp3', 'm4a', 'wav', 'aac', 'ogg', 'flac', 'opus', //
  'mp4', 'mkv', 'webm', '3gp', 'mov',
];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.university.purple_player.audio',
    androidNotificationChannelName: 'تشغيل الأغاني',
    androidNotificationOngoing: true,
    androidNotificationIcon: 'drawable/ic_notif',
  );
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: kBlack,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const PurplePlayerApp());
}

class PurplePlayerApp extends StatelessWidget {
  const PurplePlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Purple Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: kBlack,
        colorScheme: const ColorScheme.dark(
          primary: kPurple,
          secondary: kPurpleLight,
          surface: kSurface,
        ),
        sliderTheme: const SliderThemeData(
          activeTrackColor: kPurple,
          inactiveTrackColor: kSurface2,
          thumbColor: kPurpleLight,
          trackHeight: 4,
        ),
      ),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const PlayerPage(),
    );
  }
}

class Track {
  final String uri; // content:// أو مسار ملف
  final String title;
  final String artist;
  final bool isVideo;
  final Duration? duration;

  Track({
    required this.uri,
    required this.title,
    this.artist = '',
    this.isVideo = false,
    this.duration,
  });

  Uri get asUri => uri.startsWith('/') ? Uri.file(uri) : Uri.parse(uri);
}

enum _Mode { none, audio, video }

class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key});

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  static const _media = MethodChannel('purple/media');

  final AudioPlayer _audio = AudioPlayer();
  VideoPlayerController? _video;
  final List<StreamSubscription> _subs = [];

  final List<Track> _library = []; // أغاني التليفون
  final List<Track> _manual = []; // ملفات أضافها المستخدم يدويًا
  List<String> _queueUris = [];

  _Mode _mode = _Mode.none;
  Track? _current;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;
  bool _playing = false;
  bool _loading = false;
  bool _scanning = true;
  bool _denied = false;
  bool _shuffle = false;
  int _repeat = 0; // 0 بدون، 1 الكل، 2 واحدة
  bool _searching = false;
  String _query = '';
  bool _videoDone = false;

  List<Track> get _all => [..._library, ..._manual];

  List<Track> get _filtered {
    final q = _query.trim().toLowerCase();
    final all = _all;
    if (q.isEmpty) return all;
    return all
        .where((t) =>
            t.title.toLowerCase().contains(q) ||
            t.artist.toLowerCase().contains(q))
        .toList();
  }

  @override
  void initState() {
    super.initState();
    _subs.add(_audio.positionStream.listen((p) {
      if (_mode == _Mode.audio && mounted) setState(() => _pos = p);
    }));
    _subs.add(_audio.durationStream.listen((d) {
      if (_mode == _Mode.audio && d != null && mounted) {
        setState(() => _dur = d);
      }
    }));
    _subs.add(_audio.playerStateStream.listen((s) {
      if (_mode != _Mode.audio || !mounted) return;
      setState(() {
        _playing = s.playing && s.processingState != ProcessingState.completed;
        _loading = s.processingState == ProcessingState.loading;
      });
    }));
    _subs.add(_audio.currentIndexStream.listen((i) {
      if (_mode != _Mode.audio || i == null || !mounted) return;
      if (i < 0 || i >= _queueUris.length) return;
      final uri = _queueUris[i];
      final match = _all.where((t) => t.uri == uri);
      if (match.isNotEmpty) {
        setState(() {
          _current = match.first;
          _pos = Duration.zero;
          _dur = match.first.duration ?? _dur;
        });
      }
    }));
    _scan();
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    _audio.dispose();
    _video?.removeListener(_onVideoTick);
    _video?.dispose();
    super.dispose();
  }

  // ---------- مسح أغاني التليفون ----------
  Future<void> _scan() async {
    setState(() {
      _scanning = true;
      _denied = false;
    });
    bool ok = false;
    try {
      ok = await _media
              .invokeMethod<bool>('requestPermission', {'kind': 'audio'}) ??
          false;
    } catch (_) {}
    if (!ok) {
      if (!mounted) return;
      setState(() {
        _scanning = false;
        _denied = true;
      });
      return;
    }
    try {
      final res = await _media.invokeMethod<List<dynamic>>('queryAudio') ?? [];
      final list = <Track>[];
      for (final e in res) {
        final m = Map<String, dynamic>.from(e as Map);
        final artist = (m['artist'] as String?) ?? '';
        final ms = (m['duration'] as num?)?.toInt() ?? 0;
        list.add(Track(
          uri: m['uri'] as String,
          title: (m['title'] as String?) ?? 'بدون عنوان',
          artist: artist == '<unknown>' ? '' : artist,
          duration: ms > 0 ? Duration(milliseconds: ms) : null,
        ));
      }
      list.sort(
          (a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
      _library
        ..clear()
        ..addAll(list);
    } catch (_) {}
    if (!mounted) return;
    setState(() => _scanning = false);
    // صلاحية الإشعارات (أندرويد 13+)
    try {
      await _media.invokeMethod('requestPermission', {'kind': 'notification'});
    } catch (_) {}
  }

  // ---------- إضافة ملفات يدويًا (فيديو أو غيره) ----------
  Future<void> _pickFiles() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: _allExt,
    );
    if (result == null) return;
    Track? first;
    for (final f in result.files) {
      final p = f.path;
      if (p == null) continue;
      if (_all.any((t) => t.uri == p)) continue;
      final ext = (f.extension ?? '').toLowerCase();
      final t = Track(
        uri: p,
        title: f.name.replaceFirst(RegExp(r'\.[^.]+$'), ''),
        isVideo: _videoExt.contains(ext),
      );
      _manual.add(t);
      first ??= t;
    }
    setState(() {});
    if (first != null && _current == null) _playTrack(first);
  }

  // ---------- التشغيل ----------
  Future<void> _playTrack(Track t) async {
    if (t.isVideo) {
      await _playVideo(t);
    } else {
      await _playAudio(t);
    }
  }

  bool _sameList(List<String> a, List<String> b) {
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  Future<void> _playAudio(Track t) async {
    await _disposeVideo();
    final audioTracks = _all.where((x) => !x.isVideo).toList();
    final uris = audioTracks.map((x) => x.uri).toList();
    final pos = uris.indexOf(t.uri);
    if (pos < 0) return;
    setState(() {
      _mode = _Mode.audio;
      _current = t;
      _pos = Duration.zero;
      _dur = t.duration ?? Duration.zero;
      _loading = true;
    });
    try {
      if (!_sameList(uris, _queueUris)) {
        _queueUris = uris;
        final source = ConcatenatingAudioSource(children: [
          for (final x in audioTracks)
            AudioSource.uri(
              x.asUri,
              tag: MediaItem(
                id: x.uri,
                title: x.title,
                artist: x.artist.isEmpty ? null : x.artist,
                duration: x.duration,
              ),
            ),
        ]);
        await _audio.setAudioSource(source,
            initialIndex: pos, initialPosition: Duration.zero);
      } else {
        await _audio.seek(Duration.zero, index: pos);
      }
      _audio.play();
    } catch (_) {
      _snack('تعذّر تشغيل هذا الملف');
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _playVideo(Track t) async {
    _queueUris = [];
    await _audio.stop();
    await _disposeVideo();
    setState(() {
      _mode = _Mode.video;
      _current = t;
      _pos = Duration.zero;
      _dur = t.duration ?? Duration.zero;
      _loading = true;
      _videoDone = false;
    });
    final c = VideoPlayerController.file(File(t.uri));
    _video = c;
    try {
      await c.initialize();
      c.addListener(_onVideoTick);
      await c.play();
    } catch (_) {
      _snack('تعذّر تشغيل هذا الملف');
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _disposeVideo() async {
    final c = _video;
    _video = null;
    c?.removeListener(_onVideoTick);
    await c?.dispose();
  }

  void _onVideoTick() {
    final c = _video;
    if (c == null || !mounted || _mode != _Mode.video) return;
    final v = c.value;
    if (v.isInitialized &&
        !_videoDone &&
        v.duration.inMilliseconds > 0 &&
        v.position >= v.duration &&
        !v.isPlaying) {
      _videoDone = true;
      _onVideoComplete();
    }
    setState(() {
      _pos = v.position;
      _dur = v.duration;
      _playing = v.isPlaying;
    });
  }

  void _onVideoComplete() {
    if (_repeat == 2) {
      _video?.seekTo(Duration.zero);
      _video?.play();
      _videoDone = false;
      return;
    }
    _skip(1, auto: true);
  }

  void _skip(int delta, {bool auto = false}) {
    final all = _all;
    final cur = _current;
    if (all.isEmpty || cur == null) return;
    var i = all.indexWhere((t) => t.uri == cur.uri) + delta;
    if (auto && i >= all.length && _repeat == 0) return;
    i = (i + all.length) % all.length;
    _playTrack(all[i]);
  }

  void _togglePlay() {
    if (_mode == _Mode.audio) {
      if (_audio.processingState == ProcessingState.completed) {
        _audio.seek(Duration.zero, index: 0);
        _audio.play();
      } else if (_audio.playing) {
        _audio.pause();
      } else {
        _audio.play();
      }
    } else if (_mode == _Mode.video) {
      final c = _video;
      if (c == null || !c.value.isInitialized) return;
      if (c.value.position >= c.value.duration) {
        c.seekTo(Duration.zero);
        _videoDone = false;
      }
      c.value.isPlaying ? c.pause() : c.play();
    }
  }

  void _next() {
    if (_mode == _Mode.audio) {
      if (_audio.hasNext) {
        _audio.seekToNext();
      } else {
        _audio.seek(Duration.zero, index: 0);
      }
    } else if (_mode == _Mode.video) {
      _skip(1);
    }
  }

  void _prev() {
    if (_pos.inSeconds > 3) {
      _seek(Duration.zero);
      return;
    }
    if (_mode == _Mode.audio) {
      if (_audio.hasPrevious) {
        _audio.seekToPrevious();
      } else {
        _audio.seek(Duration.zero);
      }
    } else if (_mode == _Mode.video) {
      _skip(-1);
    }
  }

  void _seek(Duration d) {
    if (_mode == _Mode.audio) {
      _audio.seek(d);
    } else if (_mode == _Mode.video) {
      _video?.seekTo(d);
    }
  }

  void _toggleShuffle() {
    setState(() => _shuffle = !_shuffle);
    _audio.setShuffleModeEnabled(_shuffle);
  }

  void _cycleRepeat() {
    setState(() => _repeat = (_repeat + 1) % 3);
    _audio.setLoopMode(const [LoopMode.off, LoopMode.all, LoopMode.one][_repeat]);
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
  }

  // ---------- الواجهة ----------
  @override
  Widget build(BuildContext context) {
    final list = _filtered;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _header(),
            if (_searching) _searchBar(),
            if (_current != null) _nowPlaying(),
            Expanded(child: _body(list)),
          ],
        ),
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 8, 8),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [kPurpleLight, kPurpleDeep],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.graphic_eq_rounded, color: kBlack),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text('مشغل الأغاني',
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: kPurpleLight)),
          ),
          IconButton(
            tooltip: 'بحث',
            onPressed: () => setState(() {
              _searching = !_searching;
              if (!_searching) _query = '';
            }),
            icon: Icon(_searching ? Icons.search_off_rounded : Icons.search_rounded,
                color: kPurpleLight),
          ),
          IconButton(
            tooltip: 'تحديث القائمة',
            onPressed: _scanning ? null : _scan,
            icon: const Icon(Icons.refresh_rounded, color: kPurpleLight),
          ),
          IconButton(
            tooltip: 'إضافة ملفات',
            onPressed: _pickFiles,
            icon: const Icon(Icons.add_circle_rounded, color: kPurple, size: 30),
          ),
        ],
      ),
    );
  }

  Widget _searchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: TextField(
        autofocus: true,
        onChanged: (v) => setState(() => _query = v),
        decoration: InputDecoration(
          hintText: 'ابحث عن أغنية...',
          prefixIcon: const Icon(Icons.search_rounded, color: kPurple),
          filled: true,
          fillColor: kSurface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _body(List<Track> list) {
    if (list.isEmpty) {
      if (_scanning) {
        return const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: kPurple),
              SizedBox(height: 16),
              Text('جاري البحث عن الأغاني...',
                  style: TextStyle(color: Colors.white60)),
            ],
          ),
        );
      }
      if (_denied) {
        return _message(
          icon: Icons.lock_outline_rounded,
          title: 'نحتاج صلاحية الوصول للأغاني',
          text: 'اسمح للتطبيق بقراءة ملفات الصوت عشان يعرض لك الأغاني اللي في التليفون',
          buttons: [
            FilledButton.icon(
              onPressed: _scan,
              style: FilledButton.styleFrom(
                  backgroundColor: kPurple, foregroundColor: kBlack),
              icon: const Icon(Icons.check_rounded),
              label: const Text('السماح'),
            ),
            OutlinedButton.icon(
              onPressed: () => _media.invokeMethod('openSettings'),
              icon: const Icon(Icons.settings_rounded),
              label: const Text('فتح الإعدادات'),
            ),
          ],
        );
      }
      if (_query.isNotEmpty) {
        return _message(
          icon: Icons.search_off_rounded,
          title: 'ما في نتائج',
          text: 'جرّب كلمة تانية',
        );
      }
      return _message(
        icon: Icons.library_music_rounded,
        title: 'ما لقينا أغاني في التليفون',
        text: 'تقدر تضيف ملفات MP3 أو MP4 يدويًا',
        buttons: [
          FilledButton.icon(
            onPressed: _pickFiles,
            style: FilledButton.styleFrom(
                backgroundColor: kPurple, foregroundColor: kBlack),
            icon: const Icon(Icons.folder_open_rounded),
            label: const Text('اختيار ملفات'),
          ),
        ],
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      itemCount: list.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(4, 4, 4, 10),
            child: Text(
              _scanning
                  ? 'قائمة الأغاني (جاري التحديث...)'
                  : 'قائمة الأغاني (${list.length})',
              style: const TextStyle(
                  color: kPurpleLight,
                  fontSize: 16,
                  fontWeight: FontWeight.w600),
            ),
          );
        }
        return _tile(list[i - 1]);
      },
    );
  }

  Widget _message({
    required IconData icon,
    required String title,
    required String text,
    List<Widget> buttons = const [],
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kSurface,
                border: Border.all(color: kPurple.withOpacity(0.4), width: 2),
              ),
              child: Icon(icon, size: 52, color: kPurple),
            ),
            const SizedBox(height: 20),
            Text(title,
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text(text,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white60)),
            const SizedBox(height: 20),
            Wrap(spacing: 12, runSpacing: 8, children: buttons),
          ],
        ),
      ),
    );
  }

  Widget _tile(Track t) {
    final current = _current?.uri == t.uri;
    final sub = t.isVideo
        ? 'فيديو'
        : [
            if (t.artist.isNotEmpty) t.artist,
            if (t.duration != null) _fmt(t.duration!),
          ].join(' • ');
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: current ? kSurface2 : kSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: current ? kPurple : Colors.transparent, width: 1.2),
      ),
      child: ListTile(
        onTap: () => _playTrack(t),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: current ? kPurple : kSurface2,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            current && _playing
                ? Icons.graphic_eq_rounded
                : (t.isVideo ? Icons.movie_rounded : Icons.music_note_rounded),
            color: current ? kBlack : kPurpleLight,
          ),
        ),
        title: Text(t.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
                color: current ? kPurpleLight : Colors.white,
                fontWeight: current ? FontWeight.w600 : FontWeight.normal)),
        subtitle: sub.isEmpty
            ? null
            : Text(sub,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white38, fontSize: 12)),
      ),
    );
  }

  Widget _nowPlaying() {
    final t = _current!;
    final c = _video;
    final showVideo = _mode == _Mode.video && c != null && c.value.isInitialized;
    final maxMs = max(_dur.inMilliseconds, 1).toDouble();
    final value = _pos.inMilliseconds.toDouble().clamp(0.0, maxMs).toDouble();

    final titleBlock = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(t.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
        if (t.artist.isNotEmpty)
          Text(t.artist,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white60, fontSize: 13)),
      ],
    );

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF2A1B45), kSurface],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: kPurple.withOpacity(0.25)),
      ),
      child: Column(
        children: [
          if (showVideo) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Container(
                height: 190,
                width: double.infinity,
                color: Colors.black,
                child: Center(
                  child: AspectRatio(
                    aspectRatio: c!.value.aspectRatio,
                    child: VideoPlayer(c!),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Align(alignment: Alignment.centerRight, child: titleBlock),
          ] else
            Row(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    gradient: const RadialGradient(
                        colors: [kPurpleDeep, kBlack], radius: 0.95),
                  ),
                  child: Center(
                    child: _loading
                        ? const SizedBox(
                            width: 26,
                            height: 26,
                            child: CircularProgressIndicator(
                                strokeWidth: 3, color: kPurpleLight))
                        : Icon(
                            _playing
                                ? Icons.graphic_eq_rounded
                                : Icons.music_note_rounded,
                            size: 32,
                            color: kPurpleLight),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(child: titleBlock),
              ],
            ),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Column(
              children: [
                Slider(
                  value: value,
                  max: maxMs,
                  onChanged: (v) => _seek(Duration(milliseconds: v.toInt())),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_fmt(_pos),
                          style: const TextStyle(
                              color: Colors.white60, fontSize: 12)),
                      Text(_fmt(_dur),
                          style: const TextStyle(
                              color: Colors.white60, fontSize: 12)),
                    ],
                  ),
                ),
                const SizedBox(height: 2),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      onPressed: _toggleShuffle,
                      icon: Icon(Icons.shuffle_rounded,
                          color: _shuffle ? kPurple : Colors.white38),
                    ),
                    IconButton(
                      iconSize: 36,
                      onPressed: _prev,
                      icon: const Icon(Icons.skip_previous_rounded,
                          color: kPurpleLight),
                    ),
                    Container(
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle, color: kPurple),
                      child: IconButton(
                        iconSize: 40,
                        padding: const EdgeInsets.all(10),
                        onPressed: _togglePlay,
                        icon: Icon(
                            _playing
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                            color: kBlack),
                      ),
                    ),
                    IconButton(
                      iconSize: 36,
                      onPressed: _next,
                      icon: const Icon(Icons.skip_next_rounded,
                          color: kPurpleLight),
                    ),
                    IconButton(
                      onPressed: _cycleRepeat,
                      icon: Icon(
                        _repeat == 2
                            ? Icons.repeat_one_rounded
                            : Icons.repeat_rounded,
                        color: _repeat == 0 ? Colors.white38 : kPurple,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
