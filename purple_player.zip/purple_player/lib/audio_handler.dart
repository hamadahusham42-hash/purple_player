import 'package:audio_service/audio_service.dart';
import 'package:just_audio/just_audio.dart';

/// مسؤول عن التشغيل + إشعار التحكم + المعادل.
class PurpleAudioHandler extends BaseAudioHandler
    with QueueHandler, SeekHandler {
  final AndroidEqualizer equalizer = AndroidEqualizer();
  late final AudioPlayer player = AudioPlayer(
    audioPipeline: AudioPipeline(androidAudioEffects: [equalizer]),
  );

  PurpleAudioHandler() {
    player.playbackEventStream.listen(
      _broadcast,
      onError: (Object e, StackTrace st) {},
    );
    player.currentIndexStream.listen((i) {
      final q = queue.value;
      if (i != null && i >= 0 && i < q.length) mediaItem.add(q[i]);
    });
    // لو الملف ما عنده مدة معروفة نحدّثها من المشغّل
    player.durationStream.listen((d) {
      final i = player.currentIndex;
      final q = queue.value;
      if (i == null || d == null || i < 0 || i >= q.length) return;
      if (q[i].duration == d) return;
      final nq = List<MediaItem>.from(q);
      nq[i] = q[i].copyWith(duration: d);
      queue.add(nq);
      mediaItem.add(nq[i]);
    });
  }

  void _broadcast(PlaybackEvent event) {
    final playing = player.playing;
    playbackState.add(playbackState.value.copyWith(
      controls: [
        MediaControl.skipToPrevious,
        if (playing) MediaControl.pause else MediaControl.play,
        MediaControl.skipToNext,
      ],
      systemActions: const {
        MediaAction.seek,
        MediaAction.seekForward,
        MediaAction.seekBackward,
      },
      androidCompactActionIndices: const [0, 1, 2],
      processingState: const {
        ProcessingState.idle: AudioProcessingState.idle,
        ProcessingState.loading: AudioProcessingState.loading,
        ProcessingState.buffering: AudioProcessingState.buffering,
        ProcessingState.ready: AudioProcessingState.ready,
        ProcessingState.completed: AudioProcessingState.completed,
      }[player.processingState]!,
      playing: playing,
      updatePosition: player.position,
      bufferedPosition: player.bufferedPosition,
      speed: player.speed,
      queueIndex: event.currentIndex,
    ));
  }

  /// يحمّل قائمة التشغيل ويجهّز الأغنية رقم [index].
  Future<void> loadQueue(List<MediaItem> items, int index) async {
    queue.add(items);
    mediaItem.add(items[index]);
    await player.setAudioSource(
      ConcatenatingAudioSource(children: [
        for (final m in items) AudioSource.uri(Uri.parse(m.id)),
      ]),
      initialIndex: index,
      initialPosition: Duration.zero,
    );
  }

  Future<void> setShuffle(bool on) => player.setShuffleModeEnabled(on);

  Future<void> setLoop(int mode) => player.setLoopMode(
      const [LoopMode.off, LoopMode.all, LoopMode.one][mode]);

  @override
  Future<void> play() => player.play();

  @override
  Future<void> pause() => player.pause();

  @override
  Future<void> seek(Duration position) => player.seek(position);

  @override
  Future<void> skipToQueueItem(int index) =>
      player.seek(Duration.zero, index: index);

  @override
  Future<void> skipToNext() async {
    if (player.hasNext) {
      await player.seekToNext();
    } else {
      await player.seek(Duration.zero, index: 0);
    }
  }

  @override
  Future<void> skipToPrevious() async {
    if (player.position.inSeconds > 3) {
      await player.seek(Duration.zero);
    } else if (player.hasPrevious) {
      await player.seekToPrevious();
    } else {
      await player.seek(Duration.zero);
    }
  }

  @override
  Future<void> stop() async {
    await player.stop();
    return super.stop();
  }
}
