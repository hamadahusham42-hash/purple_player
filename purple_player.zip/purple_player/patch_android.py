"""يعدّل مشروع الأندرويد المولّد: الصلاحيات، خدمة الإشعار، ومسح الأغاني."""
import glob
import os
import re

# ---------- AndroidManifest ----------
MANIFEST = "android/app/src/main/AndroidManifest.xml"
m = open(MANIFEST, encoding="utf-8").read()
m = re.sub(r'android:label="[^"]*"', 'android:label="Purple Player"', m, count=1)

perms = """    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
"""
service = """        <service android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService"/>
            </intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON"/>
            </intent-filter>
        </receiver>
"""
if "READ_MEDIA_AUDIO" not in m:
    m = m.replace("<application", perms + "    <application", 1)
if "com.ryanheise.audioservice.AudioService" not in m:
    m = m.replace("</application>", service + "    </application>", 1)
open(MANIFEST, "w", encoding="utf-8").write(m)

# ---------- أيقونة الإشعار ----------
res = "android/app/src/main/res"
os.makedirs(res + "/drawable", exist_ok=True)
os.makedirs(res + "/raw", exist_ok=True)
open(res + "/drawable/ic_notif.xml", "w", encoding="utf-8").write(
    """<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp" android:height="24dp"
    android:viewportWidth="24" android:viewportHeight="24">
  <path android:fillColor="#FFFFFFFF"
      android:pathData="M12,3v10.55c-0.59,-0.34 -1.27,-0.55 -2,-0.55 -2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4V7h4V3h-6z"/>
</vector>
"""
)
open(res + "/raw/keep.xml", "w", encoding="utf-8").write(
    """<?xml version="1.0" encoding="utf-8"?>
<resources xmlns:tools="http://schemas.android.com/tools"
    tools:keep="@drawable/ic_notif" />
"""
)

# ---------- MainActivity ----------
KOTLIN = """package __PKG__

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : AudioServiceActivity() {
    private val pending = HashMap<Int, MethodChannel.Result>()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "purple/media")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "requestPermission" ->
                        requestPerm(call.argument<String>("kind") ?: "audio", result)
                    "openSettings" -> {
                        val i = Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", packageName, null)
                        )
                        startActivity(i)
                        result.success(true)
                    }
                    "queryAudio" -> {
                        Thread {
                            try {
                                val list = queryAudio()
                                runOnUiThread { result.success(list) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("error", e.message, null) }
                            }
                        }.start()
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun permFor(kind: String): String? {
        return if (kind == "audio") {
            if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
            else Manifest.permission.READ_EXTERNAL_STORAGE
        } else {
            if (Build.VERSION.SDK_INT >= 33) Manifest.permission.POST_NOTIFICATIONS else null
        }
    }

    private fun requestPerm(kind: String, result: MethodChannel.Result) {
        val perm = permFor(kind)
        if (perm == null || checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) {
            result.success(true)
            return
        }
        val code = if (kind == "audio") 4201 else 4202
        pending[code] = result
        requestPermissions(arrayOf(perm), code)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        pending.remove(requestCode)?.success(
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        )
    }

    private fun queryAudio(): List<Map<String, Any?>> {
        val out = ArrayList<Map<String, Any?>>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val selection = MediaStore.Audio.Media.DURATION + " >= 30000"
        val cursor = contentResolver.query(collection, projection, selection, null, null)
            ?: return out
        cursor.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id).toString()
                var title = c.getString(titleCol)
                if (title.isNullOrEmpty()) title = c.getString(nameCol) ?: ""
                val artist = c.getString(artistCol) ?: ""
                out.add(
                    mapOf(
                        "uri" to uri,
                        "title" to title,
                        "artist" to artist,
                        "duration" to c.getLong(durCol)
                    )
                )
            }
        }
        return out
    }
}
"""

found = glob.glob("android/app/src/main/**/MainActivity.*", recursive=True)
if not found:
    raise SystemExit("MainActivity not found")
old = found[0]
src = open(old, encoding="utf-8").read()
pkg = re.search(r"^package\s+([\w.]+)", src, re.M).group(1)
target = os.path.splitext(old)[0] + ".kt"
if old != target:
    os.remove(old)
open(target, "w", encoding="utf-8").write(KOTLIN.replace("__PKG__", pkg))
print("Patched:", MANIFEST, target)
