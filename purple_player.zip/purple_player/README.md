# Purple Player

مشغل أغاني وفيديو (MP3 / MP4 وغيرها) من ملفات الجهاز. تصميم بنفسجي فاتح مع أسود.

## البناء
ارفع المشروع على GitHub (فرع main) وسيعمل Action تلقائيًا.
بعد انتهائه: تبويب Actions > آخر تشغيل > Artifacts > purple-player-apk.
